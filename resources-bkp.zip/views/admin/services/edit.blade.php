@extends('admin.layout')

@section('title', 'Edit Service')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Edit Service</h2>
    <a href="{{ route('admin.services.index') }}" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Back
    </a>
</div>

<div class="card">
    <div class="card-body">
        <form action="{{ route('admin.services.update', $service) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <div class="mb-3">
                <label for="title" class="form-label">Title <span class="text-danger">*</span></label>
                <input type="text" class="form-control @error('title') is-invalid @enderror" id="title" name="title" value="{{ old('title', $service->title) }}" required>
                @error('title')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control @error('description') is-invalid @enderror" id="description" name="description" rows="5">{{ old('description', $service->description) }}</textarea>
                @error('description')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            @if($service->image)
            <div class="mb-3">
                <label class="form-label">Current Image</label>
                <div>
                    @php
                        $imagePath = \Illuminate\Support\Str::startsWith($service->image, 'uploads/')
                            ? $service->image
                            : 'uploads/' . ltrim($service->image, '/');
                    @endphp
                    <img src="{{ asset($imagePath) }}" alt="{{ $service->title }}" style="max-height: 200px;">
                </div>
            </div>
            @endif

            <div class="mb-3">
                <label for="image" class="form-label">New Image</label>
                <input type="file" class="form-control @error('image') is-invalid @enderror" id="image" name="image" accept="image/*">
                <small class="form-text text-muted">Leave empty to keep current image</small>
                @error('image')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="icon_url" class="form-label">Icon URL</label>
                <input type="url" class="form-control @error('icon_url') is-invalid @enderror" id="icon_url" name="icon_url" value="{{ old('icon_url', $service->icon_url) }}" placeholder="https://example.com/icon.svg">
                <small class="form-text text-muted">URL to icon/SVG image for this service (e.g., https://cdn.example.com/duct.svg)</small>
                @error('icon_url')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="page_id" class="form-label">Link to Page</label>
                <select class="form-select @error('page_id') is-invalid @enderror" id="page_id" name="page_id">
                    <option value="">-- No Link (Optional) --</option>
                    @foreach($pages as $page)
                        <option value="{{ $page->id }}" {{ old('page_id', $service->page_id) == $page->id ? 'selected' : '' }}>{{ $page->title }}</option>
                    @endforeach
                </select>
                <small class="form-text text-muted">Select a page to link this service. Frontend will link to this page when service is clicked.</small>
                @error('page_id')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="status" name="status" value="1" {{ old('status', $service->status) ? 'checked' : '' }}>
                    <label class="form-check-label" for="status">
                        Active
                    </label>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="bi bi-save"></i> Update Service
            </button>
        </form>
    </div>
</div>
@endsection

